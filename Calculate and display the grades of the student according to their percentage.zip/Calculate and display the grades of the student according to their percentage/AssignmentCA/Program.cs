﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentCA
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /** Console.WriteLine("hello, can we do a small exercise?");
             Console.ReadLine();

             Console.WriteLine("Welcome");
             Console.ReadLine();

             Console.WriteLine("Enter your full name");
             String myname = Console.ReadLine();

             Console.WriteLine("My name is: " + myname);

             // Declare and initialize variables with proper naming conventions
             int myInteger = 17;
             double length = 1.8;
             double width = 2.8;
             decimal perimeter = 9.7m;
             string message = "\"myInteger\" is ";

             // Calculate the area
             double area = length * width;

             // Output using consistent string interpolation
             Console.WriteLine($"{message}{myInteger}");
             Console.WriteLine();

             // Using string interpolation instead of composite formatting
             Console.WriteLine($"{message}, {myInteger}, {length}");
             Console.WriteLine();

             // Format decimal places for consistency
             Console.WriteLine($"Perimeter = {perimeter:F2}");
             Console.WriteLine();

             // Format area with 2 decimal places
             Console.WriteLine($"Area = {area:F2}");
             Console.WriteLine();

             // Wait for user input before closing
             Console.WriteLine("Press any key to exit...");
             Console.ReadKey(); **/

            // 1. Ask for student's name
            Console.Write("Enter student's name: ");
            string studentName = Console.ReadLine();

            // 2. Ask for marks in three subjects
            Console.Write("Enter marks for Subject 1 (out of 100): ");
            double subject1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter marks for Subject 2 (out of 100): ");
            double subject2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter marks for Subject 3 (out of 100): ");
            double subject3 = Convert.ToDouble(Console.ReadLine());

            // 3. Display student's name
            Console.WriteLine($"\nStudent Name: {studentName}");

            // 4. Calculate and display total marks
            double totalMarks = subject1 + subject2 + subject3;
            Console.WriteLine($"Total Marks: {totalMarks}");

            // 5. Calculate and display percentage
            double percentage = (totalMarks / 300) * 100;
            Console.WriteLine($"Percentage: {percentage:F2}%");

            // 6. Calculate and display grade
            string grade;
            if (percentage > 90)
            {
                grade = "A";
            }
            else if (percentage > 80)
            {
                grade = "B";
            }
            else if (percentage > 70)
            {
                grade = "C";
            }
            else if (percentage > 50)
            {
                grade = "D";
            }
            else
            {
                grade = "FAIL";
            }

            Console.WriteLine($"Grade: {grade}");

            // Wait for user input before closing
            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();

        }
    }
}
